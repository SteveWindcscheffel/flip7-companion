# Implementation plan — replacing the current build

This is a **replacement of the presentation layer**, not a new app. Domain logic (`src/utils/scoring.ts`, `src/utils/gameSetup.ts`, `src/services/storage.ts`, `src/types/game.ts`) and the deploy pipeline (`.github/workflows/deploy.yml`, `vite.config.ts`) stay as they are.

Work on a branch: `git checkout -b redesign/table-aesthetic`

---

## File-by-file

### `index.html` — edit
Add the three Google Fonts to `<head>` (preconnect + one stylesheet link): `Alfa Slab One`, `Oswald:wght@400;500;600;700`, `DM Sans` 400/500/700. Set the theme colour to `#0b423d`.

### `src/styles/global.css` — rewrite
This is the biggest single change. The current file is ~44k of accumulated per-screen CSS built around two overlapping token sets (`--vs-*` at ~line 1003, `--ag-*` at ~line 1421) and should be rebuilt rather than patched.

1. One `:root` block with the token table from `README.md` (colours, the ten player accents, type scale, radii, shadows).
2. The four keyframes (`f7pop`, `f7slide`, `f7fall`, `f7bob`).
3. A small shared layer: `.app-table` (gradient + grid texture + vignette), `.card` (cream gradient, gold border, the two inset rings, corner brackets via `::before` / `::after`), `.btn-primary` / `.btn-secondary` / `.btn-ghost` (including the required `:active { transform: translateY(4px) }` press), `.plaque`, `.foil-disc`, `.label` (Oswald section labels), `.numeral` (tabular figures).
4. Per-screen sections after that, in the order the screens are listed in `README.md`.

Delete the old `--vs-*` / `--ag-*` duplication — keep one set.

### `src/App.tsx` — split up
Currently ~46k with every view inline. Extract to the layout the repo README already describes, so each screen matches one section of the handoff:

| New file | Replaces | Notes |
| --- | --- | --- |
| `src/App.tsx` | the whole file | keeps state + the `view` switch only; should end up a few hundred lines |
| `src/features/home/HomeScreen.tsx` | `view === 'home'` branch | logo lockup, Resume/New/Statistics, recent games, DELETE ALL DATA two-tap |
| `src/features/new-game/NewGameScreen.tsx` | the `!activeGame` branch | roster rows, swipe-to-delete + Manage mode, add player, 2–10 cap |
| `src/features/game/PlayerCardScreen.tsx` | active-game non-entry branch | peek card stack, hero numeral, pip bar, live standings, last-rounds tiles |
| `src/features/game/ScoreEntryScreen.tsx` | `isEnteringRound` branch | keypad, validation, back-a-player, TOP 3 strip |
| `src/features/game/LeaderboardScreen.tsx` | `getLeaderboard` view | |
| `src/features/game/WinnerScreen.tsx` | `completedGame` branch | confetti over the card, scrollable standings, pinned footer |
| `src/features/stats/HallOfFameScreen.tsx` | `view === 'hall-of-fame'` | monogram foil discs, no emoji |
| `src/components/Brand.tsx` | — | the four-layer CSS wordmark |
| `src/components/PlayerCard.tsx` | — | shared by the card and entry screens |

### `src/utils/playerAccents.ts` — edit
Keep the ten colours as they are. Add a `nextAccent(usedAccents)` helper returning the first unused entry of `PLAYER_ACCENT_ORDER`, and use it in `createActiveGame` / when adding a roster player, replacing the `index % length` wrap — that wrap is why players 9 and 10 currently duplicate colours 1 and 2.

### `src/utils/gameSetup.ts` — edit
Enforce the cap in code, not just the UI: reject more than `MAX_PLAYERS` (10) in `validatePlayerNames`, and have `createActiveGame` use `nextAccent`.

### `src/App.tsx` game-completion path — behaviour fix
When a committed round produces a winner, the current code keeps the completed game around, so Home offers to resume a finished game. Clear the active game on completion (`storage.clearActiveGame()`), keep a separate snapshot for the winner screen, and gate Resume on `activeGame && activeGame.rounds.length > 0`.

### `src/App.tsx` score entry — behaviour fixes
- Reject an empty score on Next/Save with the inline message "Enter a score, or tap BUST for 0"; only BUST records 0.
- Add a back-a-player control that restores that player's draft value for correction.
- Show `NEXT ({remaining})` on the button.

### `src/assets/flip7-companion-wordmark.svg` — retire
The logo is now CSS type. Remove the import from Home; keep the SVG only if you still want it for the favicon / PWA icon.

### `public/textures/*` — keep
`felt-texture.svg` and `paper-grain.svg` still work for the table and card grain if you prefer them to the CSS grid.

### `src/features/**` tests — unchanged
`scoring.test.ts` and `gameSetup.test.ts` must still pass; add a case for the 11-player rejection and one for accent uniqueness at a full table.

---

## Order of work

1. Fonts + tokens + shared CSS layer (`index.html`, `global.css`) — nothing looks right until this lands.
2. `Brand.tsx` and `HomeScreen.tsx` — proves the aesthetic end to end.
3. `NewGameScreen.tsx` with the roster/delete behaviour and the 10-player cap.
4. `PlayerCardScreen.tsx` and `ScoreEntryScreen.tsx` — the two screens that carry the game.
5. `LeaderboardScreen.tsx`, `WinnerScreen.tsx`, `HallOfFameScreen.tsx`.
6. The three behaviour fixes above, plus tests.
7. `npm run test && npm run build`, then push — the Pages workflow deploys `main`.

## Acceptance checks

- A 10-player game: ten distinct accents; the two peek cards never match; live standings scroll inside the card; the winner's standings scroll while NEW GAME / HOME stay reachable.
- Finishing a game leaves Home with no Resume, and the game in history.
- Next with an empty field refuses to advance; BUST records 0; back restores the previous entry.
- Every button visibly depresses on tap.
