# Handoff: Flip7 Companion — visual redesign

## Overview

A full visual redesign of the Flip7 Companion scorekeeper (`SteveWindcscheffel/flip7-companion`, branch `main`). The existing app's logic — scoring, storage, statistics — stays as-is; this replaces the presentation layer so the app looks and feels like the card game it accompanies: a deep teal card table, cream playing-card surfaces, gold foil borders, coral sign-painter lettering.

The design is a working prototype: every screen, transition and rule described below is implemented and can be clicked through.

## About the design files

`Flip7 Companion.dc.html` in this bundle is a **design reference created in HTML** — a prototype showing the intended look and behaviour. It is not production code to copy. The task is to **recreate it inside the existing React + TypeScript + Vite codebase**, using that project's established patterns: screens live in `src/App.tsx` (or split into `src/features/*` as the README's project layout intends), styling in `src/styles/global.css`, scoring in `src/utils/scoring.ts`, persistence in `src/services/storage.ts`.

Do not port the prototype's inline styles verbatim. Express the tokens below as CSS custom properties in `global.css` (the file already carries an `--ag-*` / `--vs-*` set that overlaps heavily) and build the screens as components.

## Fidelity

**High-fidelity.** Colours, typography, spacing, radii, shadows and interaction states are final. Recreate them precisely.

---

## Design tokens

### Colour

| Token | Value | Use |
| --- | --- | --- |
| Table (base) | `#0f544c` → `#0b423d` → `#07322f` | App background, radial gradient `130% 80% at 50% 0%` |
| Page frame ground | `#062f2c` | `body` behind the device |
| Card cream (top) | `#fdf6e4` | Card gradient start, `170deg` |
| Card cream (bottom) | `#f1e2be` | Card gradient end |
| Row cream selected | `#fffaee` | Selected list rows (must be opaque) |
| Row cream idle | `#f2e6c9` | Unselected list rows (must be opaque) |
| Gold | `#b88a3d` | Card borders, rules, hairlines |
| Gold soft | `#d8b77a` | Screen-title text on teal, dividers |
| Gold plaque | `#e0bd77` → `#a97f31` | Round badge, foil discs, `180deg` |
| Gold plaque edge | `#f0dcab` | Plaque border |
| Coral | `#d85a49` → `#a83227` | Primary buttons, winner banner, delete, `180deg` |
| Coral edge | `#f0d59e` | Primary button border |
| Coral deep | `#8f2c1f` | Logo inline stroke |
| Coral face | `#c94a37` | Logo letter fill |
| Green (secondary) | `#1e6a4c` → `#14472f` | Resume Game, Bust button |
| Ink | `#16283d` | Body text, big score numerals |
| Ink muted | `#8a7448` | Secondary text on cream |
| Label gold | `#8a6b2e` | Section labels on cream |
| Alert / error | `#a8402f` | Error text, "over 200" flags |
| Sea text | `#9dc7bb` | Subtitles on teal |

### Player accents — all ten, from `src/utils/playerAccents.ts`

`#cf4b3f` coral-red · `#3c5ecf` royal-blue · `#2f8a55` emerald-green · `#7b53b5` amethyst-purple · `#b7862f` warm-gold · `#bb3f8d` magenta · `#4c92d9` sky-blue · `#cf6e2f` orange · `#2f7f86` teal · `#b23b63` raspberry

Assignment: a new player takes the **first unused** colour in that order, so a full 10-player table always has ten distinct accents. Accent appears on the player nameplate, leaderboard rank discs, live-standings discs, the peeking neighbour cards and the winner name.

### Typography

Google Fonts: `Alfa Slab One`, `Oswald` (400/500/600/700), `DM Sans` (400/500/700).

| Role | Font | Size / weight / tracking |
| --- | --- | --- |
| Logo wordmark | Alfa Slab One | 98px (`FLIP`) + 110px (`7`), `letter-spacing:-.02em` |
| Player total (hero numeral) | Alfa Slab One | 88px, `#16283d` |
| Score entry numeral | Alfa Slab One | 60px, tabular |
| Winner points | Alfa Slab One | 30px |
| Screen titles on teal | Oswald 700 | 24px / `.13em` |
| Button labels | Oswald 700 | 16–20px / `.10–.12em` |
| Player nameplate | Oswald 700 | 21px / `.14em`, cream on accent |
| Section labels on cream | Oswald 600 | 11–12px / `.16–.20em`, `#8a6b2e` |
| List names | Oswald 600 | 16–24px, `#16283d` |
| Body / meta | DM Sans 400–500 | 11–13px |
| Numbers in tables | DM Sans 700 | `font-variant-numeric: tabular-nums` |

### Surfaces

- **Card**: `background:linear-gradient(170deg,#fdf6e4,#f1e2be)`, `border:2px solid #b88a3d`, `border-radius:16px` (14px for list cards), `box-shadow:0 14px 30px rgba(0,0,0,.4), inset 0 0 0 3px rgba(255,255,255,.5), inset 0 0 0 4px rgba(184,138,61,.32)`. The two inset rings are the gold double-rule and are essential to the look.
- **Card corner brackets**: 22px L-shaped `border-left/top` etc. in `rgba(184,138,61,.7)`, radius 6px, absolutely positioned at the card's top corners.
- **Buttons**: `border-radius:12px`, 2px border, `box-shadow:0 5px 0 rgba(0,0,0,.34)` plus `inset 0 2px 0 rgba(255,255,255,.22)`.
- **Button press (required)**: `transform:translateY(4px); box-shadow:0 1px 0 …` on `:active`, `transition:transform .07s, box-shadow .07s`. Every button in the app has this — it is the "physical" feel of the design.
- **Felt texture**: a 26px grid of 1px lines in `#8ec9c2` at 16% opacity over the gradient, plus `inset 0 0 120px rgba(0,0,0,.55)` vignette. `src/styles/global.css` already references `/textures/felt-texture.svg` and `/textures/paper-grain.svg`; either approach is fine.

### Keyframes

```css
@keyframes f7pop   {0%{transform:scale(.9);opacity:0}60%{transform:scale(1.04)}100%{transform:scale(1);opacity:1}}
@keyframes f7slide {0%{transform:translateX(26px);opacity:0}100%{transform:translateX(0);opacity:1}}
@keyframes f7fall  {0%{transform:translateY(-40px) rotate(0);opacity:0}10%{opacity:1}100%{transform:translateY(760px) rotate(540deg);opacity:0}}
@keyframes f7bob   {0%,100%{transform:translateY(0) rotate(-4deg)}50%{transform:translateY(-6px) rotate(-4deg)}}
```

---

## Screens

Design canvas: 402 × 874 (iPhone). Screen padding is 58–66px top (clears the status bar) and 34–44px bottom (clears the home indicator).

### 1. Home

**Purpose:** entry point — resume, start, review.

**Layout** (column, `padding:66px 22px 44px`, `gap:16px`):

1. **Logo lockup** — no containing box. Rotated `-2deg`, `animation:f7bob 6s ease-in-out infinite`, `margin:16px 0 24px`.
   - A 130px × 2px gold gradient rule sits 4px above it.
   - The wordmark is **four stacked absolutely-positioned copies** of the same `FLIP` + `7` markup, in this z-order: (a) `-webkit-text-stroke:17px #f6e4bd` with `filter:drop-shadow(0 12px 16px rgba(0,0,0,.45))` — the thick cream keyline; (b) `-webkit-text-stroke:9px #8f2c1f` — dark inline; (c) `-webkit-text-stroke:4px #f8e9c8` — thin cream inline; (d) fill `#c94a37` with `text-shadow:0 4px 0 rgba(80,22,14,.5)`. Aligned `flex-end`, `gap:2px`, the `7` set 12px larger with `margin-bottom:-4px`.
   - **COMPANION plate** below: cream gradient, 2px gold border, radius 5px, Oswald 600 16px, `letter-spacing:.44em` with matching `text-indent`.
2. **Resume Game** (only when an active game has ≥1 round) — green gradient button, title line + a subline `Round {n} · {leader} leading on {total}`.
3. **New Game** — coral primary.
4. **Statistics** — cream secondary.
5. **Recent games** header: gold label, hairline, "VIEW ALL" in `#8fc0b4`.
6. **Recent games card** — up to 3 rows: a 26px gold foil disc holding the winner's initial (Oswald 700, `#4a3210`), name + "{pts} points", right column "{n} Rounds" + date.
7. Spacer, then **DELETE ALL DATA** — a small pill, `border-radius:20px`, 1.5px `rgba(216,183,122,.35)` border, transparent fill, Oswald 600 11px `.16em` in `rgba(216,183,122,.75)`. **Two-tap confirm**: first tap swaps it to a filled coral pill reading "TAP AGAIN TO CONFIRM"; it reverts after 4s; second tap wipes storage and resets all state.
8. Caption: "Scores stay on this device".

### 2. New Game

**Layout** (`padding:60px 22px 40px`): back chevron (42px, rounded 11px, translucent) · centred title "NEW GAME" + "Select 2–10 players" · a full-height cream card · coral START GAME button.

Inside the card:
- Header row: "RECENT PLAYERS" left, **MANAGE / DONE** pill right (idle: `rgba(255,255,255,.4)` fill, gold border, `#8a6b2e` text; active: gold gradient fill, `#3a2a10` text).
- **Player rows** — each is a `position:relative; overflow:hidden` wrapper containing (a) a coral DELETE panel pinned to the right at 96px wide, and (b) the row itself translated over it. Row: 22px checkbox (gold border; fills with the player's accent and shows `✓` when selected), name in Oswald 600 18px, 16px accent dot with an inset white ring. **The row background must be opaque** (`#fffaee` / `#f2e6c9`) or the delete panel bleeds through.
- **Removal, two ways:** swipe left >50px reveals the DELETE panel (swipe right or tap the row closes it); or tap MANAGE, which reveals a 34px round coral `×` on every row. Both call the same remove action, which drops the player from the roster and from the current selection.
- Hint line: "Tap to pick · swipe left or Manage to delete", replaced by "Tap × to delete a name for good" in manage mode, and by "Table full — 10 players is the maximum" at the cap.
- Add-player row: dashed-border text input + gold `+` button. Enter also submits.

**Rules:** minimum 2, maximum 10. Ticking an 11th player is refused. A name added when 10 are already selected joins the roster unselected. The button reads `START GAME (n)`, drops to `opacity:.45` and does nothing outside 2–10.

### 3. Active game — player card

**Layout** (`padding:58px 18px 34px`): header row (✕ home · gold ROUND {n} badge with "PLAYER {i} OF {n}" beneath · ☰ leaderboard) · the card stack · a 4-button footer.

**Card stack** — this is the swipe affordance:
- Two 92px-wide neighbour cards pinned `left:0` and `right:0`, inset `top:22px; bottom:22px`, in a duller cream (`#f0e0bc`→`#e2d0a6`), each showing a 16px accent tab in the **previous** / **next** player's colour plus a grey content block.
- The front card sits `left:26px; right:26px; top:0; bottom:0`, so ~26px of each neighbour peeks out. `animation:f7slide .22s ease-out`, keyed on player id so it replays on change.

**Front card contents**, top to bottom: accent nameplate (crown emoji pinned top-right when this player leads) · the total in 88px Alfa Slab One with `text-shadow:2px 3px 0 rgba(184,138,61,.35), 0 6px 14px rgba(0,0,0,.18)`, `animation:f7pop .3s` · "RACE TO 200" between hairlines · a **10-segment pip bar** (filled = `round(total/200*10)`, filled in the accent, empty `rgba(184,138,61,.16)`) · "{total} / 200" · **LIVE STANDINGS**, a scrolling list of every player (rank disc in accent, name, right-aligned total, plus an "OVER 200" / "CLOSE" flag in `#a8402f` at ≥200 / ≥170); the current player's row is brighter with a stronger border · **LAST ROUNDS**, the last four rounds as small tiles (`R11` label + score) · pagination dots flanked by `‹ ›` · caption "Swipe for other players".

**Footer:** `‹` · UNDO · coral **ENTER ROUND {n}** · `›`.

**Interactions:** arrows and horizontal swipe (>50px, and only when it exceeds vertical movement) cycle players with wraparound. UNDO removes the last round entirely.

### 4. Score entry

Same header, with the position line reading "PLAYER {i} OF {n}".

Card contents: accent nameplate · meta line "Total {running} · {k} of {n} scored this round" · the entered value in 60px Alfa Slab One inside an inset cream well (placeholder `0` at `rgba(22,40,61,.28)`) · a 14px-tall error line in `#a8402f` · an "over 200" alert bar when relevant · the **TOP 3** strip · an optional **NOW** row · a 3×4 keypad (`1–9`, `⌫`, `0`, `C`) in cream keys with `0 3px 0 rgba(184,138,61,.55)` and a 3px press.

**TOP 3 strip** — the space-efficient standings. A `TOP 3` label followed by three equal tiles: rank disc, truncated name, live total. Status is carried by the disc, costing no extra height:
- **scored this round** — disc filled with the accent, tile at full opacity;
- **entering now** — filled disc plus `box-shadow:0 0 0 2px rgba(184,138,61,.85)` gold ring;
- **still to play** — hollow disc (transparent fill, accent border, accent numeral), tile at `opacity:.55`.

If the player currently entering is outside the top 3, a **NOW** row appears beneath with their rank, name, `−{n} to lead` and total.

Totals in this strip are **live**: base total + any score already banked in the round's draft + the digits currently on the keypad.

**Footer:** `‹` back (dims to `opacity:.4` on the first player; restores that player's draft value into the keypad) · **BUST (0)** in green · coral **NEXT ({remaining})** / **SAVE ROUND** on the last player, `white-space:nowrap`.

**Validation:** tapping NEXT/SAVE with an empty field shows "Enter a score, or tap BUST for 0" and does not advance. BUST always records 0 and advances. Any keypad press clears the error. Stepping back and forward preserves entered values.

### 5. Leaderboard

Full-screen list reached from ☰. Back chevron · "LEADERBOARD" + "Round {n}". One cream card per player: 38px accent rank disc, name in Oswald 600 24px, total in Alfa Slab One 28px in the accent. A cream BACK TO GAME button pinned at the bottom.

### 6. Winner

Triggered when a round is committed and the top total ≥200.

- **26 confetti pieces** — 9×14px rounded rects in gold / coral / cream / blue / purple, `z-index:40` so they fall **over** the card, `animation:f7fall` with staggered 2.6–4.4s durations and 0–2.6s delays, `pointer-events:none`.
- Coral **WINNER** banner, Oswald 700 24px `.24em`.
- A card that is `flex:1; min-height:0; overflow:auto` — this matters: with 10 players the standings must scroll **inside** the card so the buttons below stay reachable. Winner name (36px Oswald in their accent), "{total} POINTS", "{n} rounds played", hairline, FINAL STANDINGS list.
- Footer, `flex:none`, `z-index:50`: coral **NEW GAME** · cream **HOME**.

### 7. Hall of Fame

Reached from Statistics. Rows of: a 34px gold foil disc holding a monogram (`W` most wins, `H` highest final score, `F` fastest win, `G` games recorded, `L` current leader) in Oswald 700 `#4a3210` with a white top highlight; a gold label; the value in Oswald 600 19px. **No emoji** — the monograms read as embossed foil and stay in palette.

---

## Interactions & behaviour

- **Navigation** is a single `screen` value: `home | new | game | entry | leaderboard | winner | stats`.
- **Committing a round:** append `{n, scores}` to the game's rounds. If the top total is then ≥200, the game is over: push a history entry `{winner, pts, rounds, date}`, **clear the active game** (so Home shows no Resume), keep a snapshot for the winner screen, and switch to `winner`. Otherwise return to the player card with the draft cleared.
- **A finished game must not be resumable.** Home's Resume appears only when the active game has ≥1 round; clearing the active game on completion is what enforces it.
- **Undo** drops the last round only.
- **Persistence:** the whole state serialises to `localStorage`. Transient UI flags (manage mode, swiped row, reset confirmation) are reset on load. In the real app this maps onto `storage.saveActiveGame` / `loadHistory` / `savePlayers`.

## State

`screen`, `game {players[], rounds[]}`, `roster[]`, `selected[]`, `newName`, `editMode`, `swipedId`, `cardIdx`, `entryIdx`, `entryValue`, `entryError`, `draft {playerId: score}`, `finished`, `history[]`, `confirmReset`.

Derived per render: standings (sorted totals), leader id, pip fill, per-round running totals, live draft-inclusive totals, top 3, remaining-player count, hall-of-fame records.

## Assets

No new binary assets. The logo is pure CSS type (Alfa Slab One in four stacked stroke layers) and replaces `src/assets/flip7-companion-wordmark.svg` — delete that reference or keep the SVG as a favicon source. The existing `public/textures/*.svg` remain usable for the felt and paper grain. Icons are text glyphs (`←`, `✕`, `☰`, `‹`, `›`, `×`, `⌫`) and the crown emoji on the leading player; if you prefer, swap the glyphs for Lucide icons, but keep the monogram discs in Hall of Fame.

## Files

- `Flip7 Companion.dc.html` — the complete working prototype. Open it in a browser and click through every screen; it is the source of truth for anything this README leaves ambiguous.

## Suggested order of work

1. Move the tokens above into `src/styles/global.css` as custom properties; reconcile with the existing `--ag-*` / `--vs-*` sets.
2. Add the three Google Fonts and the four keyframes.
3. Extend `PLAYER_ACCENT_ORDER` usage so accents are assigned first-unused rather than modulo.
4. Rebuild Home, then New Game, then the active-game card, then score entry, then leaderboard / winner / hall of fame.
5. Enforce the rules: 2–10 players, empty-score validation, back-a-player, no resuming a finished game.
6. Check a full 10-player game end to end on a real phone — the peek cards, the TOP 3 strip and the scrolling winner card are all sized for that worst case.
